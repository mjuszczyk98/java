module lab1 {
}